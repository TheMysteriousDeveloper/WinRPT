WinRPT 1.0 Readme
=================

WinRPT (short for Windows Report) is a powerful, flexible and easy to use tool to exfiltrate
valuable information of a PC computer running Windows operating System.

It reads the Windows Registry to extract data about the operating system, hardware, users and
- most important - recent used and opened files in many applications and software suites.

Differently of others programs of its type, data to be extracted are stored in separated  and
independent files. This allows that program source code be more lean and elgant,    giving to
both the program and its user flexibility to either choose what  to  scan  or  create its own
definitions, to do custom researches.

Please  click  on  the  Help button or read documentation  in  the help folder  to  get  more
informations.

Credits from icon file goes to: https://www.flaticon.com/br/icones-gratis/detetive-particular
